
import nitk from '../assets/images/Education/nitk.png';

export const EDUCATION_LIST = [
  {
    id: "education-1",
    icon: nitk,
    title: "National Institute of Technology Karnataka, Surathkal",
    degree: "Bachelor of Technology",
    duration: "December 2020 - April 2024",
    content1: "Major: Mechanical Engineering",
    content2: "Minor: Information Technology",
  },
];
